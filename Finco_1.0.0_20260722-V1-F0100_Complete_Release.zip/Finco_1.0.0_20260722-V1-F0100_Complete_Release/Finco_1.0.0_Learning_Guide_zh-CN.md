# Finco 1.0.0 正式版学习手册

> 从第一行 `.fin` 代码，到数学、完整 AI 训练与桌面应用 · build `20260722-V1-F0100`

本手册适用于 `.fin` / `.finco` 文件、Finco Jupyter Kernel、VS Code 与 Finco Studio。AI 库的正式名称是 `Finlai`，导入方式是 `import Finlai`。

## 1. 先认识 Finco

Finco 是一种可运行、Python 兼容的高级语言。它先把自然、宽松的 Finco 写法规范化，再转成 Python，由 Finco Runtime 和各个官方库执行。因此，你可以先用短而直观的语法学习，也可以逐步进入 Python、PyTorch 和更底层的训练控制。

Finco 追求四件事：

1. 常用操作应该短而容易读。
2. 同一种意图可以有少量友好别名，但内部含义必须唯一。
3. 自动行为必须可见；不确定的错误不能擅自猜测。
4. 简化重复代码，但不隐藏数据、任务、输出和安全边界。

Finco 1.0.0 包含语言核心、Jupyter Kernel、VS Code 扩展、Finco Studio，以及下列官方库：

| 模块 | 用途 |
|---|---|
| `Finlai` | 传统机器学习、神经网络、文本模型与强化学习 |
| `Fimath` | 显式开启的精确标量数学 |
| `FinApp` | 桌面应用与 Finco Studio |
| `FPlot` | 折线、散点、柱状、直方图和热图 |
| `Fipen` | 更易用的画笔、Canvas、图层与动画 |

> `Finlai` 是库名，角色类似 PyTorch 或 scikit-learn；Finco 才是语言名。

## 2. 安装、Studio 与第一次运行

完整发布包已经按系统分好目录：

1. macOS：双击 `Install_Finco.command`。首次被系统阻止时，右键文件并选择“打开”。
2. Windows：双击 `Install_Finco_Windows.bat`。
3. Linux：运行 `bash Install_Finco_Linux.sh`。

安装程序会创建独立环境、安装语言、注册 Kernel，并尝试安装 VS Code 扩展。安装后先运行：

```text
finco doctor
```

`doctor` 只检查，不会偷偷修改环境。它会查看 Python、证书、Kernel、PyTorch、TorchVision、传统 ML、NLTK、FastCore 和编辑器支持。

创建文件 `hello.fin`：

```finco
output "Hello, Finco!"

loop(i from 1 to 3):
    output "Round", i
```

然后选择一种方式运行：

```text
finco run hello.fin
```

也可以双击 `.fin`、在 Finco Studio 中点击 Run，或在 Notebook 中选择 **Finco** 内核。Notebook 仍使用 `.ipynb` 后缀，但每个代码单元直接写 Finco。

常用命令：

| 命令 | 含义 |
|---|---|
| `finco run main.fin` | 编译并运行 |
| `finco check main.fin` | 检查并显示纠正建议 |
| `finco normalize main.fin` | 显示规范写法 |
| `finco build main.fin` | 生成可读 Python |
| `finco new demo` | 创建项目 |
| `finco format main.fin` | 格式化源码 |
| `finco test` | 运行 `test_*.fin` |
| `finco repl` | 打开交互终端 |

## 3. 基础语法与 Python 兼容

变量会自动推断类型；常量使用 `const`：

```finco
name = "Finco"
version = 1.0
enabled = true
items = [1, 2, 3]
const PI_APPROX = 3.14159
```

输出和输入既能写成命令形式，也能写成函数形式：

```finco
output "Hello"
output "Name:", name, "Version:", version
output("Python-style call also works")

name = input "Your name: "
age = input number "Your age: "
```

条件与函数：

```finco
if score >= 90:
    output "Excellent"
else if score >= 60:
    output "Passed"
else:
    output "Try again"

function square(x):
    return x * x
```

循环中的 `to` 包含终点，`until` 不包含终点：

```finco
loop(times=3):
    output "Again"

loop(i from 1 to 3):
    output i

loop(i from 0 until 3):
    output i
```

普通 Python 写法仍然可用，例如 `print(...)`、`for`、类、异常和常用库调用。`py:` 用在你希望一段代码完全保持原始 Python、不经过 Finco 改写的时候：

```finco
py:
    from pathlib import Path
    current = Path.cwd()

output current
```

## 4. AutoCorrect 与 finco smart

AutoCorrect 有四种模式：

| 模式 | 行为 |
|---|---|
| `off` | 不纠正 |
| `safe` | 只改几乎没有歧义的问题 |
| `ask` | 不确定时显示 **Do you mean** |
| `strong` | 应用唯一且高置信的建议，并报告每项修改 |

```finco
finco autocorrect=strong

outpiit “Hello”
if score = 10：
    output success "Ready"
```

这里可以纠正 `outpiit → output`、智能引号、中文冒号以及条件中的单个 `=`。它也能处理漏逗号、漏块冒号、训练参数别名、混合调用括号和唯一相似文件路径。

`finco smart` 是方便开关：它启用 strong 纠错和安全自动导入，但不会静默联网安装软件。需要第三方包时必须明确写：

```text
finco install nltk
finco install scikit-learn
```

圆括号、尖括号和装饰括号在明确的函数调用位置可以等价；`<>` 是块语法的推荐写法，`()` 是正式别名，不会被记为错误。列表的 `[]`、集合的 `{}` 和比较符 `<` 不会被随意改写。

## 5. 集合、数学符号与 Fimath

Finco 支持常见数学字符和英文别名：

```finco
A = {x | x ∈ ℕ, x < 10}
B = {2, 4, 6, 8}

output A ∩ B
output A ∪ B
output 3 ∈ A
output A ⊆ ℕ
output ∀x in B: x > 0
output ∃x in A: x² = 9
```

没有有限上界的集合会成为延迟集合。不要试图一次生成全部元素；使用：

```finco
Even = {x | x ∈ ℕ, x mod 2 = 0}
output first(Even, 10)
```

还支持 `Σ`、`Π`、向量、矩阵和统计函数：

```finco
output Σ(i=1 to 10) i²
output mean([1, 2, 3, 4])
output matmul([[1, 2], [3, 4]], [[5, 6], [7, 8]])
```

默认计算仍遵循 Python 浮点规则。只有显式导入 Fimath 并选择模式后，普通、无副作用的标量算式才会提升为精确数：

```finco
import Fimath
Fimath.mode = "smart"

a = 0.1 + 0.2
b = 1 / 3 + 1 / 6
output a
output b
```

AI 张量、第三方库和 `py:` 不会被 Fimath 改写。需要传统行为时设置 `Fimath.mode = "traditional"`。

## 6. Finlai、数据与任务

AI 程序通常从这里开始：

```finco
import Finlai
```

Finlai 会管理重复但容易出错的工作：设备、张量转换、损失函数、优化器、训练循环、验证、指标和模型保存。它不会替你猜任务和标签含义。

加载和划分数据：

```finco
data = load_data("mnist")

train_data, valid_data, test_data = split_data(
    data,
    valid=10%,
    test=10%,
    seed=42
)
```

这表示训练 80%、验证 10%、测试 10%。三者用途不同：

| 数据 | 何时使用 | 目的 |
|---|---|---|
| `train_data` | 参数更新时 | 让模型学习 |
| `valid_data` | 每轮训练后 | 选择最佳轮次、发现过拟合、提前停止 |
| `test_data` | 训练全部结束后 | 给出最终、相对可信的评价 |

`validate=valid_data` 的英语意思是“用这份数据验证”。测试集不应该在训练期间反复查看，否则最终分数会失去客观性。

### 6.1 predict 是输出契约

模型定义里的 `predict(...)` 不是立即预测，而是在说明模型最终要输出什么：

| 写法 | 任务 | Finlai 自动准备 |
|---|---|---|
| `predict(classes=10)` | 十分类 | 10 个输出、分类损失、准确率 |
| `predict(binary=true)` | 二分类 | 二分类输出与损失 |
| `predict(values=1)` | 回归 | 连续数值输出与回归损失 |
| `predict(tokens=auto)` | 下一个 token | 词表大小输出与序列损失 |

训练完成以后，`model.predict(sample)` 才是真正执行预测。

## 7. 传统机器学习

传统 ML 适合表格、小数据、可解释基线和快速实验。Finlai 支持线性/逻辑回归、决策树、随机森林、梯度提升、SVM、KNN、朴素贝叶斯、K-Means 和 PCA。

```finco
import Finlai

data = load_data("train.csv", target="label", task="classification")
train_data, test_data = split_data(data, test=20%)

model = random_forest(n_estimators=200, seed=42)
history = train_model(model, train_data)
result = evaluate_model(model, test_data)

output result.metrics
```

传统模型通常是一次完整拟合，不需要几十轮反向传播。先用逻辑回归或决策树建立基线，再决定是否真的需要深度网络，往往更高效。

## 8. MLP、CNN 与神经网络矩阵

`dense(64)` 表示一层有 64 个输出神经元。Finlai 会根据上一层宽度创建权重矩阵和偏置，再执行：

```text
output = activation(input × weight + bias)
```

因此你不用手工计算矩阵尺寸，但可以通过 `model_summary` 查看实际结构和参数量。

### 8.1 MLP 示例

```finco
model classifier:
    input(auto)
    dense(64, activation="relu")
    dropout(20%)
    dense(32, activation="gelu")
    predict(classes=auto)

history = train_model(
    classifier,
    train_data,
    validate=valid_data,
    rounds=10,
    batch=32
)
```

`batch=32` 表示每次参数更新使用 32 个样本；`rounds=10` 表示完整学习训练集 10 遍。

### 8.2 CNN 示例

```finco
model image_classifier:
    input(auto)
    conv2d(32, kernel_size=3, activation="relu")
    max_pooling2d(pool_size=2)
    conv2d(64, kernel_size=3, activation="relu")
    max_pooling2d(pool_size=2)
    flatten()
    predict(classes=10)
```

卷积层在图像不同位置重复使用同一个小型滤波器，因此比把所有像素直接连到 Dense 更能保留局部结构。

## 9. Token、Embedding、Word2Vec 与 NLTK

神经网络不能直接接收一个单词。Tokenizer 先把文本切成 token，再把 token 映射成整数 ID：

```text
"Finco learns" → [17, 42]
```

Embedding 为每个 ID 学习一个连续向量：

```text
17 → [0.12, -0.41, 0.08, ...]
```

`embedding(128)` 表示每个 token 使用 128 维向量。它不是 one-hot 输入矩阵的手工展开，而是一个可训练查询表；数学上等价于从一个大矩阵中取出对应行，因此速度和内存都更好。

### 9.1 Word2Vec

Word2Vec 单独从邻近词学习静态词向量：

```finco
texts = [
    "king queen royal palace",
    "queen king royal crown",
    "cat dog animal home"
]

words = word2vec(
    vector_size=32,
    window=2,
    method="skipgram",
    negative=5
)

history = train_model(words, texts, rounds=20, batch=32)
output words.most_similar("king", top=5)
```

`window=2` 观察中心词左右各两个位置；Skip-gram 用中心词预测周围词；`negative=5` 表示每个真实词对搭配 5 个错误词对作为负样本。这不是训练轮数，训练轮数仍由 `rounds` 决定。

Word2Vec 的同一个词永远使用同一个向量；Transformer 的最终表示会随上下文改变。Word2Vec 不需要 VAE，也可以直接用向量点积和 softmax/负采样完成中心词与上下文词预测。

### 9.2 NLTK 与文本资源

```finco
finco install nltk
```

```finco
words = nltk_tokenize("Finco makes NLP easier!", method="wordpunct")
output stem(words, method="porter")
output nltk_ngrams(words, order=2)
```

NLTK Python 包和 NLTK 语料是两件事。Brown 等语料需要明确下载，Finco 不会静默联网：

```finco
download_nltk_data("brown")
corpus = load_nltk_corpus("brown", limit=200)
```

## 10. RNN、LSTM、GRU 与 Transformer

RNN 按顺序读取 token。普通 RNN 很容易忘记较远信息；LSTM 用输入门、遗忘门和输出门控制记忆；GRU 用更少的门获得相似目的，通常更轻量。

```finco
model recurrent_text:
    input(auto)
    embedding(64)
    lstm(96, layers=2, dropout=10%)
    predict(tokens=auto)
```

将 `lstm` 换成 `rnn` 或 `gru` 就能比较。双向结构能同时看前后文，适合分类和标注；自回归生成不能偷看未来 token。

### 10.1 Attention 与 heads

Attention 会计算“当前位置应该关注哪些位置”。一个 head 学习一种关注方式；多个 head 可以并行学习不同关系，例如局部搭配、长距离指代或句法模式。

```finco
model transformer_text:
    input(auto)
    embedding(128)
    positional_encoding()
    transformer_decoder(heads=4, layers=2, dropout=10%)
    predict(tokens=auto)
```

Embedding 维度必须能被 head 数整除。`embedding(128)` 可以配 4 或 8 个 head，每个 head 分别处理 32 或 16 维。位置编码告诉模型 token 顺序；Decoder 的因果遮罩阻止模型看到未来答案。

Finco 1.0.0 的 `transformer_decoder` 是单流因果 Decoder stack。完整的双输入 Encoder-Decoder cross-attention 仍应通过自定义层实现，不会被假装成已经完整支持。

### 10.2 文本序列与 BabyLM

```finco
corpus = load_babylm(
    track="10m",
    dataset="BabyLM-community/BabyLM-2026-Strict-Small",
    config="default",
    split="train",
    streaming=true,
    limit=2000
)

data = text_sequences(corpus, mode="word", length=64, step=16)
```

`streaming=true` 表示边读取边处理，不把整个远程数据集一次塞进内存；`split="train"` 选择训练分区；`config` 选择该数据集公开的配置。数据集网站可能改变配置名，所以报错时应查看可用配置，而不是盲目重试。

小语料产生的句子常常不自然。训练损失下降只说明模型更会预测训练分布，不等于已经理解语言；必须同时观察验证损失、测试准确率和生成样本。

## 11. BioNet、Ladder、MoE、Mamba 与 Diffusion

这些模型变化较大，因此 Finco 既提供简写，也明确实现边界。

### 11.1 BioNet

BioNet 基础连接把有效权重写成：

```text
weight = sigmoid(match_strength) × tanh(effect)
```

`match_strength` 表示连接匹配强度，`effect` 表示正向或负向效果。一个神经元的输出乘以这两项后，加入下一层神经元的贡献；所有贡献求和，再加偏置和激活函数。

```finco
model bio_classifier:
    input(auto)
    bio_dense(64, activation="relu")
    bio_dense(32, activation="relu")
    predict(classes=auto)
```

Transformer 中也能把前馈网络替换为 BioLinear：

```finco
transformer_decoder(
    heads=4,
    layers=2,
    feedforward="bio",
    feedforward_size=256
)
```

Attention、残差和 LayerNorm 保持不变，改变的是两层前馈映射。

### 11.2 Ladder Network 与 MoE

Finco 的 Ladder Network 指半监督去噪结构，不是 Ladder Diffusion：

```finco
ladder_network(128, noise=20%)
ladder_network(64, noise=10%)
```

它把有标签任务损失与无标签数据的表示重建损失结合起来。

MoE 让 Router 为每个 token 选择少数专家：

```finco
transformer_encoder(
    heads=4,
    layers=3,
    feedforward="moe",
    experts=8,
    top_k=2
)
```

每个 token 只组合得分最高的两个专家，并加入负载均衡辅助损失，避免所有 token 都挤向同一个专家。

### 11.3 Mamba/SSM 与 Diffusion

`mamba(..., backend="portable")` 是可训练、便于兼容的选择性状态空间层，不宣称复制原论文 CUDA kernel。`backend="auto"` 会优先尝试可选 `mamba-ssm`，否则使用 portable。

基础 Diffusion 包含加噪调度、噪声预测训练与 DDPM 反向采样：

```finco
process = diffusion(denoiser, steps=100, schedule="cosine")
history = train_model(process, data, rounds=20, batch=64)
samples = process.sample((2,), count=16)
```

它不是完整 Stable Diffusion 产品栈；文本编码器、VAE、大型 U-Net 与条件控制需要用户组合或注册自定义层。

## 12. 强化学习与自我博弈

强化学习不是给每个样本一个固定标签，而是让 Agent 在 Environment 中行动，根据奖励逐步改进策略。环境提供：

1. `reset()`：开始一个 episode。
2. `step(action)`：执行动作并返回新状态、奖励和是否结束。

```finco
world = GridWorld(5, 5, obstacles=[(1, 1), (2, 1)])
agent = q_learning(world.actions, exploration=0.3)

history = train_agent(agent, world, rounds=300)
output evaluate_agent(agent, world)
```

这里 `rounds` 表示 episode 数。`exploration=0.3` 表示训练早期保留探索未知动作的机会。

自我博弈让两个 Agent 互相提供训练对手：

```finco
game = LineGame(3)
north = q_learning(game.actions)
south = q_learning(game.actions)
output self_play(game, north, south, rounds=200)
```

当前正式后端是表格型 Q-learning，适合教学和小状态空间。DQN、PPO 与大规模并行环境属于后续可替换后端，文档不会把它们写成已经完成。

## 13. 训练控制、历史与底层操作

完整训练示例：

```finco
history = train_model(
    model,
    train_data,
    validate=valid_data,
    rounds=20,
    batch=64,
    optimizer="adamw",
    learning_rate=0.001,
    scheduler="cosine",
    gradient_clip=1.0,
    early_stop=4,
    save_best=true,
    device="auto",
    precision="mixed",
    seed=42
)
```

`history` 保存每轮指标、设备、学习率和训练时间，不保存一份训练语料副本：

```finco
output history.loss
output history.valid_loss
output history.best_round
output history.stopped_early
output history.training_time
```

早停监控验证指标。训练准确率继续上升而验证损失变差，通常意味着过拟合；此时停止并恢复最佳轮次是合理行为。

保存模型：

```finco
path = save_model(model, "my_model")
loaded = load_model("my_model.finmodel")
```

没有后缀时会补 `.finmodel`。只加载可信模型文件。

需要底层训练时，Finlai 还提供：

```finco
optimizer = make_optimizer(model, type="adamw", learning_rate=0.001)
prediction = forward(model, batch.inputs)
error = calculate_loss(prediction, batch.targets, task="classification")
zero_grad(optimizer)
backward(error)
optimizer.step()
```

`register_layer` 可以把自定义 PyTorch 工厂注册成新的 Finco 模型层，从而只替换研究结构，而继续复用数据、设备、保存和评估系统。

## 14. 模型检查、精度与量化

```finco
summary = model_summary(model, data=train_data)
output summary
output parameter_count(model)
output parameter_count(model, trainable_only=true)
```

参数量是所有可学习矩阵和偏置中标量的总数。共享参数只计算一次；未构建模型需要传入数据以推断形状。

训练精度可以选择 `float32`、`float64` 或受设备支持的 `mixed`。Float8 不能仅靠转换 dtype 就安全训练，因此不支持时会明确报出限制。

```finco
int8_model = quantize_model(model, weights="8bit")
tiny_test = quantize_model(model, weights="1.58bit")
output quantization_summary(int8_model)
```

动态 INT8 在后端可用时会真正压缩支持层。1bit、1.58bit、4bit 和部分 mixed 模式当前是可执行权重模拟：权重值确实改变，但仍用浮点张量储存，所以不能冒充真实物理打包或硬件加速。

## 15. Norr Sort、FastCore、预计算与并行

Finco 的 `sort(...)` 默认使用稳定 Norr Sort。它严格从 50% 处分成 L、R，从 L 提取所有大于 `min(R)` 的元素，递归排序提取组，R 只通过自然有序段归并得到有序结果，再把两者合并，最后继续处理保留的 L。

```finco
ordered = sort(values)
output sort_info()
python_ordered = sort(values, algorithm="timsort")
```

原生 C++ 后端可用时自动启用；否则回退到同语义 Python 实现。相等键保持原顺序。

FastCore 为明确圈出的数值子集使用 C++17：

```finco
finco engine=auto

fast<
    total = 0
    loop(i from 1 to 100000):
        total += i * i
>
```

AI、动态对象和第三方库仍由 Python/Finlai 执行。`auto` 可以回退；严格 `cpp` 才会在不支持时失败。

预计算和并行默认关闭，必须明确选择：

```finco
finco precompute=true

parallel(1)<
    left = load_left()
>
parallel(1)<
    right = load_right()
>
```

同编号块一起运行，最适合文件、网络和数据库 I/O。Python CPU 密集代码仍受 GIL 影响。

## 16. 安全、指定行运行与彩色输出

```finco
output success "Training completed"
output info "Using MPS"
output warning "Validation loss increased"
output error "Checkpoint failed"
```

终端支持 ANSI 颜色，Jupyter 支持富文本；非交互输出或 `NO_COLOR` 环境会自动退回纯文本。

运行完整语法块中的指定行：

```text
finco run experiment.fin --line 41
finco run experiment.fin --lines 41:58
```

Finco 会扩展到完整缩进块并补充安全上下文。`jump to line` 只为实验兼容保留，不建议用于正式程序。

局部安全执行：

```finco
sandbox(
    level=safe,
    inputs=[data],
    outputs=[answer],
    network=false,
    timeout=10
):
    answer = mean(data)
```

`safe` 是受限子进程，适合隔离普通错误；面对恶意代码应使用依赖 Docker 的 `strict`。安全沙盒 Kernel 故意不保留跨单元变量。

## 17. FinApp、FPlot、Fipen 与下一步

FinApp 用简短声明创建桌面应用：

```finco
import FinApp

app welcome:
    title "Finco App"
    size 900 x 620
    theme cool
    label "Hello from Finco", size=22
    button "Close", action="close"

launch welcome
```

FPlot 负责数据图表；Fipen 保留“移动画笔”的直觉，并增加保留式 Canvas、批量刷新、图层与帧动画。

建议学习顺序：

1. 运行 `hello.fin`，熟悉 output、变量和循环。
2. 用集合和 Fimath 做一个小数学实验。
3. 用 tiny 数据比较逻辑回归、随机森林和 MLP。
4. 用 MNIST 训练 CNN，观察 train、valid、test 的差异。
5. 用同一段文本比较 Word2Vec、LSTM、Transformer 和 n-gram。
6. 将 Dense 替换为 BioDense，再尝试 MoE 或 Ladder。
7. 用 GridWorld 理解奖励、探索与 episode。
8. 每次环境异常先运行 `finco doctor`。

> Finco 1.0.0 的原则：让简单意图保持简单，让自动行为保持可见，让尚未完成的边界保持诚实。
