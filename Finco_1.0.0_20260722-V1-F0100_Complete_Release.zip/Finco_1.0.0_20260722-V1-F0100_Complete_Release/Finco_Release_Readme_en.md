# Finco 1.0.0 Release Package

Build: `20260722-V1-F0100`.

On macOS, open `Install_Finco.command`. On Windows, open `Install_Finco_Windows.bat`. On Linux, run `bash Install_Finco_Linux.sh`. The macOS installer also places the combined `Finco Studio.app` in the user Applications folder and registers `.fin`/`.finco`, so the IDE opens from Launchpad or by double-clicking a source file. The installer creates a private environment, registers the Finco Jupyter Kernel and installs the VS Code extension when available. PyTorch is installed only after explicit confirmation.

After installation:

```text
finco ide
finco run examples/hello.fin
finco doctor
```

The combined `Finco Studio.app` includes the brand icon, workspace sidebar, line numbers, run/check/format actions and an output panel. `Finco_IDE.fin` remains available and launches the same IDE. `docs` contains Chinese, English and Finnish guides. `examples` covers AI, reinforcement learning, self-play, Fipen, FPlot, FastCore and Norr Sort.

The ZIP archives use standard UTF-8 paths without Finder metadata and can be extracted on Windows, Linux and macOS.
