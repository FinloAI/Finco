# Finco 1.0.0 Complete Release

Build: `20260722-V1-F0100`

This distribution bundle contains the complete macOS, Windows, Linux, all-platform, and source archives. Use the package matching your operating system, or use `All_Platforms` when distributing Finco to several systems.

## Contents

1. `Finco_1.0.0_20260722-V1-F0100_macOS.zip`
2. `Finco_1.0.0_20260722-V1-F0100_Windows.zip`
3. `Finco_1.0.0_20260722-V1-F0100_Linux.zip`
4. `Finco_1.0.0_20260722-V1-F0100_All_Platforms.zip`
5. `Finco_1.0.0_20260722-V1-F0100_Source.zip`
6. `Finco_1.0.0_20260722-V1-F0100_SHA256.txt`
7. `Finco_Logo_High_Resolution_1464x540.png`
8. `Finco_Token_Language_Model.fin`
9. Chinese, English, and Finnish learning guides in both Word and Markdown.
10. Release manifest and Chinese, English, and Finnish release readmes.

## Verify

On macOS or Linux, open a terminal in this folder and run:

```bash
shasum -a 256 -c Finco_1.0.0_20260722-V1-F0100_SHA256.txt
```

The checksum file also lists standalone wheels, documentation, and the VS Code extension distributed separately from this bundle.
