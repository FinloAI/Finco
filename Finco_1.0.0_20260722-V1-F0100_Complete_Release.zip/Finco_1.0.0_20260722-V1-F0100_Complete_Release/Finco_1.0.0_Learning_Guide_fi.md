# Finco 1.0.0 – virallinen oppimisopas

> Ensimmäisestä `.fin`-ohjelmasta matematiikkaan, kokonaiseen tekoälykoulutukseen ja työpöytäsovelluksiin · koonti `20260722-V1-F0100`

Opas kattaa `.fin` / `.finco` -tiedostot, Finco Jupyter -ytimen, VS Coden ja Finco Studion. Virallinen tekoälykirjasto on `Finlai`, ja se tuodaan komennolla `import Finlai`.

## 1. Tutustu Fincoon

Finco on suoritettava ja Python-yhteensopiva korkean tason ohjelmointikieli. Se normalisoi helppolukuisen syntaksinsa, muuntaa sen Pythoniksi ja suorittaa sen Finco Runtimella ja virallisilla kirjastoilla. Aloittelija voi käyttää lyhyitä muotoja ja siirtyä vähitellen Pythoniin, PyTorchiin ja alatason koulutuksen hallintaan.

Fincoa ohjaa neljä periaatetta:

1. Tavallisten toimintojen pitää olla lyhyitä ja helppolukuisia.
2. Samalla aikomuksella voi olla muutama ystävällinen alias, mutta sisäisen merkityksen pitää olla yksikäsitteinen.
3. Automaattisen toiminnan pitää näkyä; epävarmaa korjausta ei arvata.
4. Toistuvaa koodia voidaan piilottaa, mutta data, tehtävä, tulos ja turvallisuusraja pidetään näkyvissä.

Finco 1.0.0 sisältää kielen ytimen, Jupyter-ytimen, VS Code -laajennuksen, Finco Studion ja seuraavat viralliset kirjastot:

| Moduuli | Käyttötarkoitus |
|---|---|
| `Finlai` | Perinteinen ML, neuroverkot, tekstimallit ja vahvistusoppiminen |
| `Fimath` | Erikseen käyttöön otettava tarkka skalaarimatematiikka |
| `FinApp` | Työpöytäsovellukset ja Finco Studio |
| `FPlot` | Viiva-, piste-, pylväs-, histogrammi- ja lämpökartat |
| `Fipen` | Helppo kynä, säilyttävä Canvas, tasot ja animaatio |

> `Finlai` on kirjaston nimi, jonka rooli muistuttaa PyTorchia tai scikit-learnia. Finco on ohjelmointikieli.

## 2. Asennus, Studio ja ensimmäinen suoritus

Täydellinen julkaisu on jaettu käyttöjärjestelmittäin:

1. macOS: avaa `Install_Finco.command`. Jos Gatekeeper estää sen, napsauta oikealla ja valitse **Avaa**.
2. Windows: avaa `Install_Finco_Windows.bat`.
3. Linux: suorita `bash Install_Finco_Linux.sh`.

Asennin luo erillisen ympäristön, asentaa kielen, rekisteröi ytimen ja yrittää asentaa VS Code -laajennuksen. Tarkista tulos:

```text
finco doctor
```

`doctor` on vain luku -tarkistus. Se tutkii Pythonin, varmenteet, ytimet, PyTorchin, TorchVisionin, perinteisen ML:n, NLTK:n, FastCoren ja editorituen.

Luo `hello.fin`:

```finco
output "Hello, Finco!"

loop(i from 1 to 3):
    output "Round", i
```

Suorita päätteessä:

```text
finco run hello.fin
```

Voit myös kaksoisnapsauttaa `.fin`-tiedostoa, painaa Run Finco Studiossa tai valita Notebookissa **Finco**-ytimen. Notebook käyttää yhä `.ipynb`-päätettä, mutta koodisolut sisältävät suoraan Fincoa.

| Komento | Merkitys |
|---|---|
| `finco run main.fin` | Käännä ja suorita |
| `finco check main.fin` | Tarkista ja näytä korjaukset |
| `finco normalize main.fin` | Näytä kanoninen Finco |
| `finco build main.fin` | Luo luettava Python |
| `finco new demo` | Luo projekti |
| `finco format main.fin` | Muotoile lähdekoodi |
| `finco test` | Suorita `test_*.fin` |
| `finco repl` | Avaa vuorovaikutteinen komentotulkki |

## 3. Perussyntaksi ja Python-yhteensopivuus

Muuttujien tyypit päätellään automaattisesti; vakio käyttää sanaa `const`:

```finco
name = "Finco"
version = 1.0
enabled = true
items = [1, 2, 3]
const PI_APPROX = 3.14159
```

Syötteellä ja tulostuksella on komento- ja funktiomuoto:

```finco
output "Hello"
output "Name:", name, "Version:", version
output("Python-style calls also work")

name = input "Your name: "
age = input number "Your age: "
```

Ehdot ja funktiot:

```finco
if score >= 90:
    output "Excellent"
else if score >= 60:
    output "Passed"
else:
    output "Try again"

function square(x):
    return x * x
```

`to` sisältää loppuarvon, `until` jättää sen pois:

```finco
loop(times=3):
    output "Again"

loop(i from 1 to 3):
    output i

loop(i from 0 until 3):
    output i
```

Tavalliset Python-muodot, kuten `print(...)`, `for`, luokat, poikkeukset ja kirjastokutsut toimivat edelleen. Käytä `py:`-lohkoa, kun koodin pitää säilyä raakana Pythonina ilman Fincon muunnoksia:

```finco
py:
    from pathlib import Path
    current = Path.cwd()

output current
```

## 4. AutoCorrect ja finco smart

| Tila | Toiminta |
|---|---|
| `off` | Ei korjauksia |
| `safe` | Korjaa vain varmat virheet |
| `ask` | Näyttää **Do you mean** -ehdotuksen epävarmassa tilanteessa |
| `strong` | Käyttää yhden yksikäsitteisen, hyvin varman korjauksen ja raportoi muutokset |

```finco
finco autocorrect=strong

outpiit “Hello”
if score = 10：
    output success "Ready"
```

Finco voi korjata `outpiit → output`, älykkäät lainausmerkit, täysleveän kaksoispisteen ja ehdon yksittäisen yhtäsuuruusmerkin. Se tunnistaa myös puuttuvan pilkun tai lohkon kaksoispisteen, koulutusparametrien aliasnimet, sekoitetut kutsusulkeet ja yhden yksikäsitteisen samankaltaisen projektipolun.

`finco smart` ottaa käyttöön strong-korjauksen ja turvallisen automaattisen tuonnin. Se ei koskaan asenna verkosta salaa:

```text
finco install nltk
finco install scikit-learn
```

Kaarisulkeet, kulmasulkeet ja koristeelliset sulkeet voivat olla virallisia aliaksia yksiselitteisessä kutsussa. `<>` on lohkojen suositus; `()` on samanarvoinen alias. Listan `[]`, joukon `{}` ja vertailun `<` merkitystä ei arvata uudelleen.

## 5. Joukot, matemaattiset merkit ja Fimath

Finco ymmärtää tavalliset matemaattiset merkit ja sanalliset aliakset:

```finco
A = {x | x ∈ ℕ, x < 10}
B = {2, 4, 6, 8}

output A ∩ B
output A ∪ B
output 3 ∈ A
output A ⊆ ℕ
output ∀x in B: x > 0
output ∃x in A: x² = 9
```

Rajoittamaton joukko on laiska. Lue äärellinen alku sen sijaan, että yrittäisit luoda kaikki jäsenet:

```finco
Even = {x | x ∈ ℕ, x mod 2 = 0}
output first(Even, 10)
```

Summat, tulot, matriisit ja tilastot ovat suoritettavia:

```finco
output Σ(i=1 to 10) i²
output mean([1, 2, 3, 4])
output matmul([[1, 2], [3, 4]], [[5, 6], [7, 8]])
```

Pythonin liukuluvut ovat oletus. Tarkka skalaarilaskenta alkaa vain eksplisiittisessä Fimath-tilassa:

```finco
import Fimath
Fimath.mode = "smart"

a = 0.1 + 0.2
b = 1 / 3 + 1 / 6
output a
output b
```

Fimath ei muuta tekoälytensoreita, kolmannen osapuolen koodia eikä `py:`-lohkoja. `Fimath.mode = "traditional"` säilyttää tavallisen Python-semantiiikan.

## 6. Finlai, data ja tehtävät

Useimmat tekoälyohjelmat alkavat näin:

```finco
import Finlai
```

Finlai hoitaa toistuvat ja virhealttiit osat: laitteet, tensorimuunnokset, häviöt, optimoijat, koulutussilmukat, validoinnin, mittarit ja mallien tallennuksen. Se ei keksi tehtävää tai selitteiden merkitystä.

```finco
data = load_data("mnist")

train_data, valid_data, test_data = split_data(
    data,
    valid=10%,
    test=10%,
    seed=42
)
```

Tuloksena on 80 % koulutusta, 10 % validointia ja 10 % testiä:

| Data | Käyttöhetki | Tarkoitus |
|---|---|---|
| `train_data` | Parametripäivitysten aikana | Mallin oppiminen |
| `valid_data` | Koulutuskierrosten jälkeen | Paras kierros, ylisovitus ja aikainen pysäytys |
| `test_data` | Kaikkien koulutuspäätösten jälkeen | Lopullinen, luotettavampi arvio |

`validate=valid_data` tarkoittaa “validoi tällä datalla”. Jos testijoukkoa käytetään toistuvasti säätämiseen, lopullinen tulos ei ole enää yhtä objektiivinen.

### 6.1 predict on tulossopimus

Mallin sisäinen `predict(...)` kuvaa tavoitellun tuloksen; se ei vielä suorita päättelyä:

| Muoto | Tehtävä | Finlain valmistelu |
|---|---|---|
| `predict(classes=10)` | Kymmenen luokan luokittelu | 10 tulosta, luokitteluhäviö ja tarkkuus |
| `predict(binary=true)` | Binääriluokittelu | Binääritulos ja häviö |
| `predict(values=1)` | Regressio | Jatkuva arvo ja regressiohäviö |
| `predict(tokens=auto)` | Seuraava token | Sanaston kokoinen tulos ja sekvenssihäviö |

Koulutuksen jälkeen `model.predict(sample)` tekee varsinaisen ennusteen.

## 7. Perinteinen koneoppiminen

Perinteinen ML sopii taulukkodataan, pienempiin aineistoihin, tulkittaviin vertailumalleihin ja nopeisiin kokeisiin. Finlai tukee lineaarista ja logistista regressiota, päätöspuita, satunnaismetsiä, gradienttitehostusta, SVM:ää, KNN:ää, naiivia Bayesia, K-Meansia ja PCA:ta.

```finco
import Finlai

data = load_data("train.csv", target="label", task="classification")
train_data, test_data = split_data(data, test=20%)

model = random_forest(n_estimators=200, seed=42)
history = train_model(model, train_data)
result = evaluate_model(model, test_data)

output result.metrics
```

Useimmat perinteiset mallit sovitetaan kerran eikä kymmenien neuroverkkokierrosten ajan. Logistinen regressio tai päätöspuu kannattaa rakentaa vertailutasoksi ennen syvän mallin valintaa.

## 8. MLP, CNN ja neuroverkon matriisit

`dense(64)` luo kerroksen, jossa on 64 ulostuloneuronia. Finlai päättelee syöteleveyden, luo painomatriisin ja biasin sekä laskee:

```text
output = activation(input × weight + bias)
```

Matriisikokoja ei tarvitse laskea käsin, mutta `model_summary` näyttää rakenteen ja parametrimäärän.

### 8.1 MLP-esimerkki

```finco
model classifier:
    input(auto)
    dense(64, activation="relu")
    dropout(20%)
    dense(32, activation="gelu")
    predict(classes=auto)

history = train_model(
    classifier,
    train_data,
    validate=valid_data,
    rounds=10,
    batch=32
)
```

`batch=32` käyttää 32 näytettä yhtä parametripäivitystä kohti. `rounds=10` käy koulutusjoukon kokonaan läpi kymmenen kertaa.

### 8.2 CNN-esimerkki

```finco
model image_classifier:
    input(auto)
    conv2d(32, kernel_size=3, activation="relu")
    max_pooling2d(pool_size=2)
    conv2d(64, kernel_size=3, activation="relu")
    max_pooling2d(pool_size=2)
    flatten()
    predict(classes=10)
```

Konvoluutio käyttää samaa pientä suodatinta kuvan eri kohdissa. Näin paikallinen rakenne säilyy luontevammin kuin kytkemällä jokainen pikseli suoraan Dense-kerrokseen.

## 9. Tokenit, Embedding, Word2Vec ja NLTK

Neuroverkko ei voi käsitellä sanaa suoraan. Tokenizer jakaa tekstin tokeneiksi ja muuntaa ne kokonaislukutunnuksiksi:

```text
"Finco learns" → [17, 42]
```

Embedding oppii jokaiselle tunnukselle jatkuvan vektorin:

```text
17 → [0.12, -0.41, 0.08, ...]
```

`embedding(128)` antaa tokenille 128 opittavaa ulottuvuutta. Se on tehokas opittava hakutaulu eikä käsin laajennettu one-hot-matriisi.

### 9.1 Word2Vec

Word2Vec oppii staattisia vektoreita vierekkäisistä sanoista:

```finco
texts = [
    "king queen royal palace",
    "queen king royal crown",
    "cat dog animal home"
]

words = word2vec(
    vector_size=32,
    window=2,
    method="skipgram",
    negative=5
)

history = train_model(words, texts, rounds=20, batch=32)
output words.most_similar("king", top=5)
```

`window=2` tarkastelee kahta paikkaa molemmilla puolilla. Skip-gram ennustaa ympäröivät sanat keskussanasta. `negative=5` lisää viisi tarkoituksella väärää sanaparia jokaista oikeaa paria kohti; se ei ole kierrosten määrä. Koulutuksen pituuden määrää `rounds`.

Word2Vec käyttää samaa vektoria sanalle kaikissa yhteyksissä. Transformerin lopullinen esitys muuttuu lauseen mukaan. Word2Vec ei tarvitse VAE:ta: vektorien pistetulo ja softmax tai negatiivinen otanta muodostavat ennustustavoitteen.

### 9.2 NLTK ja korpukset

```text
finco install nltk
```

```finco
words = nltk_tokenize("Finco makes NLP easier!", method="wordpunct")
output stem(words, method="porter")
output nltk_ngrams(words, order=2)
```

NLTK:n Python-paketti ja NLTK-korpukset ovat eri asioita. Brownin kaltaiset korpukset ladataan erikseen:

```finco
download_nltk_data("brown")
corpus = load_nltk_corpus("brown", limit=200)
```

## 10. RNN, LSTM, GRU ja Transformer

RNN lukee tokenit järjestyksessä. Tavallinen RNN kadottaa helposti kaukaista tietoa. LSTM käyttää syöte-, unohdus- ja ulostuloportteja muistin hallintaan. GRU saavuttaa saman tavoitteen harvemmilla porteilla ja on usein kevyempi.

```finco
model recurrent_text:
    input(auto)
    embedding(64)
    lstm(96, layers=2, dropout=10%)
    predict(tokens=auto)
```

Vaihda `lstm` muotoon `rnn` tai `gru` vertailua varten. Kaksisuuntainen verkko sopii luokitteluun ja merkintään, joissa koko syöte näkyy. Autoregressiivinen generointi ei saa lukea tulevia tokeneita.

### 10.1 Attention ja headit

Attention arvioi, mitkä muut sijainnit ovat tärkeitä nykyiselle sijainnille. Eri headit voivat oppia eri suhteita, kuten paikallisia ilmauksia, pitkiä viittauksia tai rakenteellisia kuvioita.

```finco
model transformer_text:
    input(auto)
    embedding(128)
    positional_encoding()
    transformer_decoder(heads=4, layers=2, dropout=10%)
    predict(tokens=auto)
```

Embedding-leveyden pitää jakautua headien määrällä. Leveydellä 128 neljä headia saa 32 ulottuvuutta ja kahdeksan 16. Paikkakoodaus kertoo järjestyksen; Decoderin kausaalimaski estää tulevien vastausten näkemisen.

Finco 1.0.0 toteuttaa `transformer_decoder`-rakenteen yksivirtaisena kausaalisena Decoder-pakkana. Täysi kahden syötteen Encoder-Decoder cross-attentionilla tehdään vielä mukautetulla kerroksella eikä sitä esitetä valmiina.

### 10.2 Tekstisekvenssit ja BabyLM

```finco
corpus = load_babylm(
    track="10m",
    dataset="BabyLM-community/BabyLM-2026-Strict-Small",
    config="default",
    split="train",
    streaming=true,
    limit=2000
)

data = text_sequences(corpus, mode="word", length=64, step=16)
```

`streaming=true` käsittelee tietueita niiden saapuessa eikä lataa koko etäaineistoa muistiin. `split="train"` valitsee koulutusosion ja `config` aineiston julkaiseman kokoonpanon. Aineistosivusto voi nimetä kokoonpanoja uudelleen, joten tarkista käytettävissä olevat nimet latausvirheen yhteydessä.

Lyhyt korpus tuottaa usein heikkoja lauseita. Pienenevä koulutushäviö kertoo vain paremmasta sovituksesta koulutusjakaumaan; validointihäviö, testitarkkuus ja tuotetut näytteet pitää arvioida yhdessä.

## 11. BioNet, Ladder, MoE, Mamba ja Diffusion

Rakenteet eroavat paljon toisistaan. Finco tarjoaa niille lyhyen syntaksin mutta kertoo myös todelliset toteutusrajat.

### 11.1 BioNet

BioNetin perusyhteyden parametrisointi on:

```text
weight = sigmoid(match_strength) × tanh(effect)
```

`match_strength` kuvaa yhteyden sopivuutta ja `effect` positiivista tai negatiivista vaikutusta. Neuronin ulostulo kerrotaan molemmilla ja lisätään seuraavan neuronin vaikutukseen. Vaikutukset summataan ennen biasia ja aktivointia.

```finco
model bio_classifier:
    input(auto)
    bio_dense(64, activation="relu")
    bio_dense(32, activation="relu")
    predict(classes=auto)
```

Transformer voi korvata feed-forward-verkkonsa BioLinearilla:

```finco
transformer_decoder(
    heads=4,
    layers=2,
    feedforward="bio",
    feedforward_size=256
)
```

Attention, jäännösyhteydet ja LayerNorm säilyvät; kaksi feed-forward-muunnosta vaihtuvat.

### 11.2 Ladder Network ja MoE

Fincon Ladder Network on puoliohjattu kohinanpoistorakenne, ei Ladder Diffusion:

```finco
ladder_network(128, noise=20%)
ladder_network(64, noise=10%)
```

Se yhdistää selitteellisen tehtävän häviön ja selitteettömien esimerkkien esitysten rekonstruktion.

MoE:n Router valitsee jokaiselle tokenille vain muutaman ekspertin:

```finco
transformer_encoder(
    heads=4,
    layers=3,
    feedforward="moe",
    experts=8,
    top_k=2
)
```

Jokaiselle tokenille yhdistetään kaksi parhaiten pisteytettyä eksperttiä. Kuormantasauksen apuhäviö estää kaikkia tokeneita valitsemasta samaa eksperttiä.

### 11.3 Mamba/SSM ja Diffusion

`mamba(..., backend="portable")` on koulutettava ja siirrettävä selektiivinen tila-avaruuskerros. Se ei väitä kopioivansa alkuperäistä CUDA-kerneliä. `backend="auto"` yrittää ensin valinnaista `mamba-ssm`-taustaa ja käyttää sitten portable-versiota.

Diffusionin perusta sisältää kohina-aikataulun, kohinan ennustuskoulutuksen ja DDPM:n käänteisen näytteenoton:

```finco
process = diffusion(denoiser, steps=100, schedule="cosine")
history = train_model(process, data, rounds=20, batch=64)
samples = process.sample((2,), count=16)
```

Tämä ei ole koko Stable Diffusion -tuotepino. Tekstienkooderi, VAE, suuri U-Net ja ehdollistus pitää koostaa tai rekisteröidä erikseen.

## 12. Vahvistusoppiminen ja itsepeluu

Vahvistusoppimisessa jokaisella esimerkillä ei ole kiinteää selitettä. Agentti toimii ympäristössä ja oppii palkkioista. Ympäristö tarjoaa:

1. `reset()` aloittaa episodi.
2. `step(action)` palauttaa uuden tilan, palkkion ja päättymistiedon.

```finco
world = GridWorld(5, 5, obstacles=[(1, 1), (2, 1)])
agent = q_learning(world.actions, exploration=0.3)

history = train_agent(agent, world, rounds=300)
output evaluate_agent(agent, world)
```

Tässä `rounds` laskee episodeja. `exploration=0.3` säilyttää mahdollisuuden kokeilla tuntemattomia toimintoja koulutuksessa.

Itsepeluussa agentit tuottavat vastustajia toisilleen:

```finco
game = LineGame(3)
north = q_learning(game.actions)
south = q_learning(game.actions)
output self_play(game, north, south, rounds=200)
```

Julkaistu tausta on taulukkopohjainen Q-learning opetukseen ja pieniin tila-avaruuksiin. DQN, PPO ja suuret rinnakkaisympäristöt ovat myöhempiä vaihdettavia taustoja.

## 13. Koulutuksen hallinta, historia ja alatason toiminnot

```finco
history = train_model(
    model,
    train_data,
    validate=valid_data,
    rounds=20,
    batch=64,
    optimizer="adamw",
    learning_rate=0.001,
    scheduler="cosine",
    gradient_clip=1.0,
    early_stop=4,
    save_best=true,
    device="auto",
    precision="mixed",
    seed=42
)
```

`history` tallentaa kierroskohtaiset mittarit, laitteen, oppimisnopeuden ja ajan, ei kopiota koulutuskorpuksesta:

```finco
output history.loss
output history.valid_loss
output history.best_round
output history.stopped_early
output history.training_time
```

Aikainen pysäytys seuraa validointia. Jos koulutustarkkuus nousee mutta validointihäviö huononee, kyse on todennäköisesti ylisovituksesta. Paras kierros kannattaa palauttaa.

```finco
path = save_model(model, "my_model")
loaded = load_model("my_model.finmodel")
```

Finco lisää `.finmodel`-päätteen tarvittaessa. Lataa vain luotettuja mallitiedostoja.

Manuaalinen koulutusaskel:

```finco
optimizer = make_optimizer(model, type="adamw", learning_rate=0.001)
prediction = forward(model, batch.inputs)
error = calculate_loss(prediction, batch.targets, task="classification")
zero_grad(optimizer)
backward(error)
optimizer.step()
```

`register_layer` julkaisee mukautetun PyTorch-tehtaan Finco-mallikerroksena. Näin tutkimusrakenne voidaan vaihtaa ja data-, laite-, tallennus- ja arviointijärjestelmät säilyttää.

## 14. Mallin tarkistus, tarkkuus ja kvantisointi

```finco
summary = model_summary(model, data=train_data)
output summary
output parameter_count(model)
output parameter_count(model, trainable_only=true)
```

Parametrimäärä on painomatriisien ja biasien opittavien skalaariarvojen määrä. Jaettu parametri lasketaan kerran; rakentamaton malli tarvitsee dataa muodon päättelyyn.

Koulutus tukee `float32`-, `float64`- ja laiteriippuvaista `mixed`-tarkkuutta. Float8 ei muutu yleisesti koulutuskelpoiseksi pelkällä dtype-muunnoksella, joten rajoitus ilmoitetaan selvästi.

```finco
int8_model = quantize_model(model, weights="8bit")
tiny_test = quantize_model(model, weights="1.58bit")
output quantization_summary(int8_model)
```

Dynaaminen INT8 pakkaa tuetut kerrokset oikeasti, kun tausta on käytettävissä. 1bit, 1.58bit, 4bit ja osa mixed-tiloista ovat suoritettavia painosimulaatioita: arvot muuttuvat, mutta tallennus pysyy liukulukuna. Niitä ei kuvata fyysisenä pakkauksena tai laitteistokiihdytyksenä.

## 15. Norr Sort, FastCore, esilaskenta ja rinnakkaisuus

Fincon `sort(...)` käyttää oletuksena vakaata Norr Sortia. Se jakaa 50 prosentista, poimii L:stä kaikki arvot, jotka ovat suurempia kuin `min(R)`, järjestää poimitun ryhmän rekursiivisesti, tekee R:stä järjestetyn vain luonnollisia jaksoja yhdistämällä, yhdistää ryhmät ja jatkaa lopuksi säilyneellä L:llä.

```finco
ordered = sort(values)
output sort_info()
python_ordered = sort(values, algorithm="timsort")
```

Alkuperäinen C++ valitaan, kun se on käytettävissä; muuten käytetään saman semantiikan Python-toteutusta. Samanarvoiset avaimet säilyttävät alkuperäisen järjestyksen.

FastCore käyttää C++17:ää eksplisiittisesti rajattuun numeeriseen osajoukkoon:

```finco
finco engine=auto

fast<
    total = 0
    loop(i from 1 to 100000):
        total += i * i
>
```

Tekoäly, dynaamiset oliot ja kolmannen osapuolen kirjastot jäävät Python/Finlai-moottorille. `auto` voi palata Pythoniin; tiukka `cpp` epäonnistuu tukemattomasta syntaksista.

Esilaskenta ja rinnakkaisuus otetaan käyttöön erikseen:

```finco
finco precompute=true

parallel(1)<
    left = load_left()
>
parallel(1)<
    right = load_right()
>
```

Saman numeron lohkot suoritetaan yhdessä. Tämä sopii parhaiten tiedosto-, verkko- ja tietokanta-I/O:hon; Pythonin CPU-raskas koodi on edelleen GIL:n rajoittama.

## 16. Turvallisuus, valittujen rivien suoritus ja värit

```finco
output success "Training completed"
output info "Using MPS"
output warning "Validation loss increased"
output error "Checkpoint failed"
```

Pääte käyttää ANSI-värejä ja Jupyter rikasta esitystä. Ei-vuorovaikutteinen tulostus ja `NO_COLOR` palaavat automaattisesti pelkkään tekstiin.

Suorita valitut kokonaiset syntaksilohkot:

```text
finco run experiment.fin --line 41
finco run experiment.fin --lines 41:58
```

Finco laajentaa valinnan koko sisennyslohkoon ja lisää turvallisen kontekstin. `jump to line` on vain kokeellista yhteensopivuutta varten eikä sitä suositella tuotantoon.

```finco
sandbox(
    level=safe,
    inputs=[data],
    outputs=[answer],
    network=false,
    timeout=10
):
    answer = mean(data)
```

`safe` on rajoitettu aliprosessi tavallisia virheitä varten. Haitallinen koodi vaatii Docker-pohjaisen `strict`-tilan. Hiekkalaatikko-Notebook-ytimet eivät tarkoituksella säilytä muuttujia solujen välillä.

## 17. FinApp, FPlot, Fipen ja seuraavat askeleet

```finco
import FinApp

app welcome:
    title "Finco App"
    size 900 x 620
    theme cool
    label "Hello from Finco", size=22
    button "Close", action="close"

launch welcome
```

FPlot tekee datakaaviot. Fipen säilyttää liikkuvan kynän ajatusmallin ja lisää säilyttävän Canvasin, eräpäivitykset, tasot ja ruutuanimaation.

Suositeltu oppimisjärjestys:

1. Suorita `hello.fin` ja opettele output, muuttujat ja silmukat.
2. Kokeile joukkoilmausta ja Fimathia.
3. Vertaa logistista regressiota, satunnaismetsää ja MLP:tä `tiny`-datalla.
4. Kouluta MNIST-CNN ja vertaa koulutus-, validointi- ja testituloksia.
5. Vertaa Word2Veciä, LSTM:ää, Transformeria ja n-grammia samalla tekstillä.
6. Korvaa Dense BioDensellä ja kokeile sitten MoE:ta tai Ladderia.
7. Ymmärrä GridWorldilla palkkio, tutkiminen ja episodit.
8. Suorita `finco doctor` ensin, kun ympäristö toimii odottamattomasti.

> Finco 1.0.0 pitää yksinkertaisen aikomuksen yksinkertaisena, automaattisen toiminnan näkyvänä ja keskeneräiset rajat rehellisinä.
