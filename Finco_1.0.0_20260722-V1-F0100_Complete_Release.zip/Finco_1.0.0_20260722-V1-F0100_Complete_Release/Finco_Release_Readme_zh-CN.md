# Finco 1.0.0 发布包

构建：`20260722-V1-F0100`。

macOS 双击 `Install_Finco.command`；Windows 双击 `Install_Finco_Windows.bat`；Linux 运行 `bash Install_Finco_Linux.sh`。macOS 安装器还会把合并版 `Finco Studio.app` 放入用户“应用程序”文件夹并注册 `.fin`/`.finco` 文件；之后可以从启动台打开 IDE，也可以直接双击 Finco 文件。安装器会建立独立环境、注册 Finco Jupyter Kernel，并在可用时安装 VS Code 扩展。神经网络后端 PyTorch 由用户明确确认后安装。

安装后可运行：

```text
finco ide
finco run examples/hello.fin
finco doctor
```

合并版 `Finco Studio.app` 包含品牌图标、项目侧栏、行号、运行、检查、格式化和输出面板；`Finco_IDE.fin` 仍然保留并可启动同一个 IDE。`docs` 包含中文、英文、芬兰语手册；`examples` 包含 AI、强化学习、自我博弈、Fipen、FPlot、FastCore 和 Norr Sort 示例。

ZIP 使用标准 UTF-8 路径与无 macOS 元数据的打包方式，可在 Windows、Linux 与 macOS 解压。
