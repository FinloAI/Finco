# Finco 1.0.0 Official Learning Guide

> From your first `.fin` program to mathematics, complete AI training and desktop apps · build `20260722-V1-F0100`

This guide covers `.fin` / `.finco` files, the Finco Jupyter Kernel, VS Code and Finco Studio. The official AI library is `Finlai`, imported with `import Finlai`.

## 1. Meet Finco

Finco is an executable, Python-compatible high-level language. It normalizes its friendly syntax, translates it to Python, and runs it through the Finco Runtime and official libraries. You can begin with short, readable code and move gradually toward Python, PyTorch and low-level training control.

Finco follows four principles:

1. Common operations should be short and readable.
2. One intent may have a few friendly aliases, but its internal meaning must remain unique.
3. Automatic behavior must be visible; uncertain repairs must not be guessed.
4. Repetitive code may be hidden, but data, tasks, outputs and safety boundaries must stay clear.

Finco 1.0.0 includes the language core, Jupyter Kernel, VS Code extension, Finco Studio and these official libraries:

| Module | Purpose |
|---|---|
| `Finlai` | Classical ML, neural networks, text models and reinforcement learning |
| `Fimath` | Explicit exact scalar mathematics |
| `FinApp` | Desktop apps and Finco Studio |
| `FPlot` | Line, scatter, bar, histogram and heatmap plots |
| `Fipen` | An approachable pen, retained canvas, layers and animation |

> `Finlai` is a library name, comparable in role to PyTorch or scikit-learn. Finco is the language.

## 2. Installation, Studio and your first run

The complete release separates files by operating system:

1. macOS: open `Install_Finco.command`. If Gatekeeper blocks it, right-click and choose **Open**.
2. Windows: open `Install_Finco_Windows.bat`.
3. Linux: run `bash Install_Finco_Linux.sh`.

The installer creates an isolated environment, installs the language, registers the Kernel and attempts to install the VS Code extension. Check the result with:

```text
finco doctor
```

`doctor` is read-only. It inspects Python, certificates, kernels, PyTorch, TorchVision, classical ML, NLTK, FastCore and editor integration.

Create `hello.fin`:

```finco
output "Hello, Finco!"

loop(i from 1 to 3):
    output "Round", i
```

Run it in a terminal:

```text
finco run hello.fin
```

You may also double-click a `.fin` file, press Run in Finco Studio, or select the **Finco** kernel in a Notebook. The Notebook still uses `.ipynb`; its code cells contain Finco directly.

| Command | Meaning |
|---|---|
| `finco run main.fin` | Compile and run |
| `finco check main.fin` | Check and show corrections |
| `finco normalize main.fin` | Show canonical Finco |
| `finco build main.fin` | Generate readable Python |
| `finco new demo` | Create a project |
| `finco format main.fin` | Format source |
| `finco test` | Run `test_*.fin` |
| `finco repl` | Open the interactive shell |

## 3. Core syntax and Python compatibility

Variables infer their types; constants use `const`:

```finco
name = "Finco"
version = 1.0
enabled = true
items = [1, 2, 3]
const PI_APPROX = 3.14159
```

Input and output support command and function forms:

```finco
output "Hello"
output "Name:", name, "Version:", version
output("Python-style calls also work")

name = input "Your name: "
age = input number "Your age: "
```

Conditions and functions:

```finco
if score >= 90:
    output "Excellent"
else if score >= 60:
    output "Passed"
else:
    output "Try again"

function square(x):
    return x * x
```

`to` includes its endpoint; `until` excludes it:

```finco
loop(times=3):
    output "Again"

loop(i from 1 to 3):
    output i

loop(i from 0 until 3):
    output i
```

Normal Python forms such as `print(...)`, `for`, classes, exceptions and library calls remain valid. Use `py:` when a block must stay raw Python and bypass Finco rewriting:

```finco
py:
    from pathlib import Path
    current = Path.cwd()

output current
```

## 4. AutoCorrect and finco smart

| Mode | Behavior |
|---|---|
| `off` | No correction |
| `safe` | Repair deterministic problems only |
| `ask` | Display **Do you mean** when uncertain |
| `strong` | Apply one unique high-confidence repair and report every change |

```finco
finco autocorrect=strong

outpiit “Hello”
if score = 10：
    output success "Ready"
```

Finco can repair `outpiit → output`, smart quotes, a full-width colon and one equals sign in a condition. It also handles missing commas or block colons, training-parameter aliases, mixed call brackets and one uniquely similar project path.

`finco smart` enables strong correction and safe automatic imports. It never silently installs from the network. Installation remains explicit:

```text
finco install nltk
finco install scikit-learn
```

Parentheses, angle brackets and decorative brackets can be official aliases in unambiguous call positions. `<>` is recommended for block syntax; `()` is an equal alias, not an error. List brackets, set braces and comparison signs are never rewritten blindly.

## 5. Sets, mathematical notation and Fimath

Finco understands common mathematical characters and word aliases:

```finco
A = {x | x ∈ ℕ, x < 10}
B = {2, 4, 6, 8}

output A ∩ B
output A ∪ B
output 3 ∈ A
output A ⊆ ℕ
output ∀x in B: x > 0
output ∃x in A: x² = 9
```

An unbounded set is lazy. Read a finite prefix instead of trying to create every member:

```finco
Even = {x | x ∈ ℕ, x mod 2 = 0}
output first(Even, 10)
```

Summation, products, matrices and statistics are executable:

```finco
output Σ(i=1 to 10) i²
output mean([1, 2, 3, 4])
output matmul([[1, 2], [3, 4]], [[5, 6], [7, 8]])
```

Python floating point remains the default. Exact scalar promotion begins only after an explicit Fimath mode:

```finco
import Fimath
Fimath.mode = "smart"

a = 0.1 + 0.2
b = 1 / 3 + 1 / 6
output a
output b
```

Fimath does not rewrite AI tensors, third-party code or `py:` blocks. Set `Fimath.mode = "traditional"` to retain ordinary Python semantics.

## 6. Finlai, data and tasks

Most AI programs begin with:

```finco
import Finlai
```

Finlai manages repetitive, error-prone work: devices, tensor conversion, losses, optimizers, training loops, validation, metrics and model persistence. It does not invent your task or label meaning.

```finco
data = load_data("mnist")

train_data, valid_data, test_data = split_data(
    data,
    valid=10%,
    test=10%,
    seed=42
)
```

This produces 80% training, 10% validation and 10% test data:

| Data | When it is used | Purpose |
|---|---|---|
| `train_data` | During parameter updates | Learn the model |
| `valid_data` | After training rounds | Select the best round, detect overfitting and stop early |
| `test_data` | After all training decisions | Produce a final, more trustworthy score |

`validate=valid_data` literally means “validate with this data.” Repeatedly tuning against the test set makes the final result less objective.

### 6.1 predict is an output contract

Inside a model, `predict(...)` describes the intended output; it does not run inference immediately:

| Form | Task | What Finlai prepares |
|---|---|---|
| `predict(classes=10)` | Ten-way classification | 10 outputs, classification loss and accuracy |
| `predict(binary=true)` | Binary classification | Binary output and loss |
| `predict(values=1)` | Regression | Continuous output and regression loss |
| `predict(tokens=auto)` | Next-token prediction | Vocabulary-sized output and sequence loss |

After training, `model.predict(sample)` performs a real prediction.

## 7. Classical machine learning

Classical ML is valuable for tables, smaller datasets, interpretable baselines and quick experiments. Finlai supports linear/logistic regression, decision trees, random forests, gradient boosting, SVM, KNN, Naive Bayes, K-Means and PCA.

```finco
import Finlai

data = load_data("train.csv", target="label", task="classification")
train_data, test_data = split_data(data, test=20%)

model = random_forest(n_estimators=200, seed=42)
history = train_model(model, train_data)
result = evaluate_model(model, test_data)

output result.metrics
```

Most classical models fit once rather than performing many neural-network rounds. Begin with logistic regression or a tree baseline before deciding that a deep model is necessary.

## 8. MLPs, CNNs and neural-network matrices

`dense(64)` creates a layer with 64 output neurons. Finlai infers the input width, creates the weight matrix and bias, and computes:

```text
output = activation(input × weight + bias)
```

You do not need to calculate matrix dimensions by hand, but `model_summary` reveals the concrete structure and parameter count.

### 8.1 MLP example

```finco
model classifier:
    input(auto)
    dense(64, activation="relu")
    dropout(20%)
    dense(32, activation="gelu")
    predict(classes=auto)

history = train_model(
    classifier,
    train_data,
    validate=valid_data,
    rounds=10,
    batch=32
)
```

`batch=32` uses 32 samples per parameter update. `rounds=10` makes ten complete passes over the training set.

### 8.2 CNN example

```finco
model image_classifier:
    input(auto)
    conv2d(32, kernel_size=3, activation="relu")
    max_pooling2d(pool_size=2)
    conv2d(64, kernel_size=3, activation="relu")
    max_pooling2d(pool_size=2)
    flatten()
    predict(classes=10)
```

A convolution reuses a small filter across image locations. It preserves local structure more naturally than connecting every pixel directly to a Dense layer.

## 9. Tokens, Embedding, Word2Vec and NLTK

A neural network cannot consume a word directly. A tokenizer first splits text into tokens and maps them to integer IDs:

```text
"Finco learns" → [17, 42]
```

An Embedding learns a continuous vector for every ID:

```text
17 → [0.12, -0.41, 0.08, ...]
```

`embedding(128)` assigns 128 trainable dimensions to each token. It is an efficient learned lookup table rather than a manually expanded one-hot matrix.

### 9.1 Word2Vec

Word2Vec learns static vectors from neighboring words:

```finco
texts = [
    "king queen royal palace",
    "queen king royal crown",
    "cat dog animal home"
]

words = word2vec(
    vector_size=32,
    window=2,
    method="skipgram",
    negative=5
)

history = train_model(words, texts, rounds=20, batch=32)
output words.most_similar("king", top=5)
```

`window=2` observes two positions on each side. Skip-gram predicts surrounding words from a center word. `negative=5` adds five deliberately wrong word pairs per real pair; it is not the number of rounds. Training duration remains controlled by `rounds`.

Word2Vec uses one vector per word in every context. A Transformer's final representation changes with its sentence. Word2Vec does not require a VAE: vector dot products and softmax or negative sampling provide the word-prediction objective.

### 9.2 NLTK and corpora

```text
finco install nltk
```

```finco
words = nltk_tokenize("Finco makes NLP easier!", method="wordpunct")
output stem(words, method="porter")
output nltk_ngrams(words, order=2)
```

The NLTK Python package and NLTK corpora are separate. Corpora such as Brown must be downloaded explicitly:

```finco
download_nltk_data("brown")
corpus = load_nltk_corpus("brown", limit=200)
```

## 10. RNN, LSTM, GRU and Transformer

An RNN reads tokens in order. A basic RNN easily loses distant information; LSTM uses input, forget and output gates to manage memory; GRU reaches a similar goal with fewer gates and is often lighter.

```finco
model recurrent_text:
    input(auto)
    embedding(64)
    lstm(96, layers=2, dropout=10%)
    predict(tokens=auto)
```

Replace `lstm` with `rnn` or `gru` to compare them. Bidirectional networks can inspect both sides and suit classification or tagging; autoregressive generation must not read future tokens.

### 10.1 Attention and heads

Attention estimates which other positions matter to the current position. Each head can learn a different relationship, such as local phrases, long-distance references or structural patterns.

```finco
model transformer_text:
    input(auto)
    embedding(128)
    positional_encoding()
    transformer_decoder(heads=4, layers=2, dropout=10%)
    predict(tokens=auto)
```

The embedding width must be divisible by the number of heads. With width 128, four heads receive 32 dimensions each and eight receive 16. Positional encoding carries order; a Decoder's causal mask prevents access to future answers.

Finco 1.0.0 implements `transformer_decoder` as a single-stream causal Decoder stack. A full two-input Encoder-Decoder with cross-attention remains a custom-layer task and is not presented as complete.

### 10.2 Text sequences and BabyLM

```finco
corpus = load_babylm(
    track="10m",
    dataset="BabyLM-community/BabyLM-2026-Strict-Small",
    config="default",
    split="train",
    streaming=true,
    limit=2000
)

data = text_sequences(corpus, mode="word", length=64, step=16)
```

`streaming=true` processes records as they arrive instead of loading the entire remote dataset into memory. `split="train"` selects the training partition, while `config` selects one configuration published by that dataset. Dataset sites can rename configurations, so inspect the available names when a loader reports a mismatch.

Short corpora often generate poor sentences. Falling training loss only means better fit to the training distribution; validation loss, test accuracy and generated samples must be examined together.

## 11. BioNet, Ladder, MoE, Mamba and Diffusion

These structures differ substantially, so Finco provides concise syntax while stating the real boundary of each implementation.

### 11.1 BioNet

BioNet's basic connection parameterization is:

```text
weight = sigmoid(match_strength) × tanh(effect)
```

`match_strength` measures connection matching; `effect` gives a positive or negative influence. A neuron's output is multiplied by both values and contributes to the next neuron. Contributions are summed before bias and activation.

```finco
model bio_classifier:
    input(auto)
    bio_dense(64, activation="relu")
    bio_dense(32, activation="relu")
    predict(classes=auto)
```

A Transformer can replace its feed-forward network with BioLinear:

```finco
transformer_decoder(
    heads=4,
    layers=2,
    feedforward="bio",
    feedforward_size=256
)
```

Attention, residual connections and LayerNorm remain standard; the two feed-forward mappings change.

### 11.2 Ladder Network and MoE

Finco's Ladder Network is the semi-supervised denoising structure, not Ladder Diffusion:

```finco
ladder_network(128, noise=20%)
ladder_network(64, noise=10%)
```

It combines labeled-task loss with representation reconstruction on unlabeled examples.

MoE lets a router choose a small number of experts for each token:

```finco
transformer_encoder(
    heads=4,
    layers=3,
    feedforward="moe",
    experts=8,
    top_k=2
)
```

Only the two highest-scoring experts are combined for each token. A load-balancing auxiliary loss discourages every token from choosing the same expert.

### 11.3 Mamba/SSM and Diffusion

`mamba(..., backend="portable")` is a trainable, portable selective state-space layer; it does not claim to reproduce the original CUDA kernel. `backend="auto"` first attempts optional `mamba-ssm`, then uses portable.

The basic Diffusion process includes a noise schedule, noise-prediction training and DDPM reverse sampling:

```finco
process = diffusion(denoiser, steps=100, schedule="cosine")
history = train_model(process, data, rounds=20, batch=64)
samples = process.sample((2,), count=16)
```

This is not the full Stable Diffusion product stack. A text encoder, VAE, large U-Net and conditioning must be composed or registered separately.

## 12. Reinforcement learning and self-play

Reinforcement learning does not supply a fixed label for every example. An Agent acts in an Environment and improves from rewards. An environment provides:

1. `reset()` to begin an episode.
2. `step(action)` to return the new state, reward and completion flag.

```finco
world = GridWorld(5, 5, obstacles=[(1, 1), (2, 1)])
agent = q_learning(world.actions, exploration=0.3)

history = train_agent(agent, world, rounds=300)
output evaluate_agent(agent, world)
```

Here `rounds` counts episodes. `exploration=0.3` preserves a chance to try unfamiliar actions during learning.

Self-play allows two agents to generate opponents for one another:

```finco
game = LineGame(3)
north = q_learning(game.actions)
south = q_learning(game.actions)
output self_play(game, north, south, rounds=200)
```

The released backend is tabular Q-learning for teaching and small state spaces. DQN, PPO and large parallel environments remain future replaceable backends.

## 13. Training control, history and low-level operations

```finco
history = train_model(
    model,
    train_data,
    validate=valid_data,
    rounds=20,
    batch=64,
    optimizer="adamw",
    learning_rate=0.001,
    scheduler="cosine",
    gradient_clip=1.0,
    early_stop=4,
    save_best=true,
    device="auto",
    precision="mixed",
    seed=42
)
```

`history` stores per-round metrics, device, learning rate and time, not a duplicate of the training corpus:

```finco
output history.loss
output history.valid_loss
output history.best_round
output history.stopped_early
output history.training_time
```

Early stopping monitors validation performance. If training accuracy rises while validation loss worsens, overfitting is likely; stopping and restoring the best round is sensible.

```finco
path = save_model(model, "my_model")
loaded = load_model("my_model.finmodel")
```

Finco adds `.finmodel` when omitted. Load only trusted model files.

For a manual training step:

```finco
optimizer = make_optimizer(model, type="adamw", learning_rate=0.001)
prediction = forward(model, batch.inputs)
error = calculate_loss(prediction, batch.targets, task="classification")
zero_grad(optimizer)
backward(error)
optimizer.step()
```

`register_layer` exposes a custom PyTorch factory as a Finco model layer, so researchers can replace the structure while reusing data, devices, saving and evaluation.

## 14. Model inspection, precision and quantization

```finco
summary = model_summary(model, data=train_data)
output summary
output parameter_count(model)
output parameter_count(model, trainable_only=true)
```

Parameter count is the number of trainable scalar values across weight matrices and biases. Shared parameters count once; an unbuilt model needs data for shape inference.

Training supports `float32`, `float64` and device-dependent `mixed` precision. Float8 cannot be made generally trainable by a dtype conversion alone, so unsupported cases report a clear limitation.

```finco
int8_model = quantize_model(model, weights="8bit")
tiny_test = quantize_model(model, weights="1.58bit")
output quantization_summary(int8_model)
```

Dynamic INT8 genuinely compresses supported layers when the backend exists. 1bit, 1.58bit, 4bit and some mixed modes are executable weight simulations: values change, but storage remains floating point, so they are not described as physical packing or hardware acceleration.

## 15. Norr Sort, FastCore, precomputation and parallel work

Finco's `sort(...)` defaults to stable Norr Sort. It splits at 50%, extracts from L every value greater than `min(R)`, recursively orders the extracted group, makes R ordered only by merging natural runs, merges both groups, and finally continues with retained L.

```finco
ordered = sort(values)
output sort_info()
python_ordered = sort(values, algorithm="timsort")
```

Native C++ is selected when available, otherwise a Python implementation with the same semantics is used. Equal keys retain their original order.

FastCore applies C++17 to an explicitly bounded numerical subset:

```finco
finco engine=auto

fast<
    total = 0
    loop(i from 1 to 100000):
        total += i * i
>
```

AI, dynamic objects and third-party libraries remain in Python/Finlai. `auto` may fall back; strict `cpp` fails on unsupported syntax.

Precomputation and parallel blocks are opt-in:

```finco
finco precompute=true

parallel(1)<
    left = load_left()
>
parallel(1)<
    right = load_right()
>
```

Blocks with the same number run together. This best suits file, network and database I/O; Python CPU-heavy code remains affected by the GIL.

## 16. Safety, selected-line execution and colored output

```finco
output success "Training completed"
output info "Using MPS"
output warning "Validation loss increased"
output error "Checkpoint failed"
```

Terminals use ANSI color and Jupyter uses rich display. Non-interactive output and `NO_COLOR` automatically fall back to plain text.

Run selected complete syntax blocks:

```text
finco run experiment.fin --line 41
finco run experiment.fin --lines 41:58
```

Finco expands to the full indentation block and adds safe context. `jump to line` remains only for experiment compatibility and is not recommended for production.

```finco
sandbox(
    level=safe,
    inputs=[data],
    outputs=[answer],
    network=false,
    timeout=10
):
    answer = mean(data)
```

`safe` is a restricted subprocess for ordinary mistakes. Malicious code requires Docker-backed `strict`. Sandboxed notebook kernels intentionally do not preserve variables between cells.

## 17. FinApp, FPlot, Fipen and next steps

```finco
import FinApp

app welcome:
    title "Finco App"
    size 900 x 620
    theme cool
    label "Hello from Finco", size=22
    button "Close", action="close"

launch welcome
```

FPlot creates data charts. Fipen keeps the moving-pen mental model while adding a retained canvas, batched updates, layers and frame animation.

Suggested learning path:

1. Run `hello.fin` and learn output, variables and loops.
2. Try one set-expression and Fimath experiment.
3. Compare logistic regression, random forest and an MLP on `tiny` data.
4. Train an MNIST CNN and compare train, validation and test results.
5. Compare Word2Vec, LSTM, Transformer and n-gram on the same text.
6. Replace Dense with BioDense, then try MoE or Ladder.
7. Use GridWorld to understand rewards, exploration and episodes.
8. Run `finco doctor` first whenever the environment behaves unexpectedly.

> Finco 1.0.0 keeps simple intent simple, automatic behavior visible, and unfinished boundaries honest.
