# Finco 1.0.0 -julkaisupaketti

Koonti: `20260722-V1-F0100`.

macOS: avaa `Install_Finco.command`. Windows: avaa `Install_Finco_Windows.bat`. Linux: suorita `bash Install_Finco_Linux.sh`. macOS-asennin sijoittaa yhdistetyn `Finco Studio.app` -sovelluksen käyttäjän Ohjelmat-kansioon ja rekisteröi `.fin`/`.finco`-tiedostot, joten IDE voidaan avata Launchpadista tai lähdetiedostoa kaksoisnapsauttamalla. Asennin luo erillisen ympäristön, rekisteröi Finco Jupyter -ytimen ja asentaa VS Code -laajennuksen, kun se on käytettävissä. PyTorch asennetaan vain käyttäjän selkeällä vahvistuksella.

Asennuksen jälkeen:

```text
finco ide
finco run examples/hello.fin
finco doctor
```

Yhdistetyssä `Finco Studio.app` -sovelluksessa on brändikuvake, työtilan sivupalkki, rivinumerot, suoritus-, tarkistus- ja muotoilutoiminnot sekä tulostepaneeli. `Finco_IDE.fin` säilyy mukana ja käynnistää saman IDE:n. `docs` sisältää kiinan-, englannin- ja suomenkieliset oppaat. `examples` sisältää AI-, vahvistusoppimis-, itsepeluu-, Fipen-, FPlot-, FastCore- ja Norr Sort -esimerkit.

ZIP-arkistot käyttävät tavallisia UTF-8-polkuja ilman Finder-metatietoja ja toimivat Windowsissa, Linuxissa ja macOS:ssä.
